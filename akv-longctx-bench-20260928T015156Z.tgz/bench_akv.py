#!/usr/bin/env python3
"""Long-context bench + correctness probe for the llama.cpp adaptive-KV-streaming fork.

This is the second-generation driver. The first generation (build 994250) swept
a cross product of contexts x arenas at N=1 and judged output by eyeballing a
400-character sample. That produced a suspicious result -- at ctx=262144 with
--kv-stream-arena-mib 3072 the model emitted "TheTheThe..." while the
streaming-off control at the same context emitted coherent text -- which could
not be adjudicated from the data it collected.

Three things changed here, all aimed at deciding "arena too small (config)"
versus "streaming returns wrong KV (bug)":

1. EXACT TOKEN COMPARISON, not coherence-by-eyeball. Every arm runs at
   temperature 0 with ignore_eos and cache_prompt off, so for a fixed prompt
   the decoded token sequence is a deterministic function of the attention
   result. The fork claims to preserve EXACT attention over the full context.
   If that claim holds, a streaming-on arm must emit the SAME token ids as the
   streaming-off arm at the same context and prompt. We record the full
   predicted token id list per arm and report the first index at which it
   diverges from its control. Divergence at any index is a correctness
   finding; "incoherent-looking text" on its own is not.

2. PER-CELL REPEATS. Same reason, opposite direction: at temperature 0 a
   correct implementation must also be self-consistent. If two repeats of the
   SAME arm disagree, the streaming path is nondeterministic, which is a
   stronger bug signal than any comparison against a control.

3. NON-REPETITIVE FILLER. The old prompt was one token id repeated ~262k
   times. Repetitive prompts degenerate on their own, so that prompt cannot
   distinguish prompt-driven degeneration from KV corruption. --filler-text-file
   takes real prose, tokenizes it through the server's own tokenizer, and uses
   those ids as the prefix. filler="token" preserves the old behaviour so the
   original observation can be reproduced under identical conditions before
   anything is varied.

Arms are specified explicitly (--arms) rather than as a cross product, because
the interesting matrix is ragged: three repeats where reproduction matters, one
where it is only a sanity check.

Failures (OOM, startup failure, timeout) are recorded as rows and the sweep
continues; the driver exits non-zero only if no arm succeeded.
"""
import argparse
import json
import os
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path


def http_json(url, payload, timeout):
    data = json.dumps(payload).encode()
    req = urllib.request.Request(
        url, data=data, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())


def gpu_used_mib(smi, index):
    out = subprocess.run(
        [smi, "--query-gpu=memory.used", "--format=csv,noheader,nounits",
         f"--id={index}"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, check=True,
    ).stdout.strip().splitlines()[0]
    return int(out)


def proc_peak_kib(pid):
    try:
        with open(f"/proc/{pid}/status") as fh:
            for line in fh:
                if line.startswith("VmHWM:"):
                    return int(line.split()[1])
    except OSError:
        pass
    return 0


class Sampler(threading.Thread):
    """Poll GPU + process RSS in the background so we capture peaks, not endpoints."""

    def __init__(self, smi, gpu_index, pid, interval=1.0):
        super().__init__(daemon=True)
        self.smi, self.gpu_index, self.pid = smi, gpu_index, pid
        self.interval = interval
        self.peak_vram_mib = 0
        self.peak_rss_kib = 0
        # NOT `self._stop`: threading.Thread already defines a private _stop()
        # method, and shadowing it with an Event breaks Thread.join().
        self._stop_event = threading.Event()

    def run(self):
        while not self._stop_event.is_set():
            try:
                self.peak_vram_mib = max(self.peak_vram_mib,
                                         gpu_used_mib(self.smi, self.gpu_index))
            except Exception:
                pass
            self.peak_rss_kib = max(self.peak_rss_kib, proc_peak_kib(self.pid))
            self._stop_event.wait(self.interval)

    def stop(self):
        self._stop_event.set()
        self.join(timeout=10)


def server_command(a, ctx, arena_mib):
    cmd = [
        str(a.server), "-m", str(a.model),
        "--alias", "akv-bench",
        "--host", "127.0.0.1", "--port", str(a.port),
        "--ctx-size", str(ctx),
        "-fa", "on",
        "-ctk", a.cache_type_k, "-ctv", a.cache_type_v,
        "-ngl", "all",
        "-b", str(a.batch_size), "-ub", str(a.ubatch_size),
        "-np", "1",
        "--no-mmproj", "--no-warmup",
        "--fit", "off",
        "--reasoning-format", "none",
    ]
    if arena_mib > 0:
        cmd += ["--kv-stream-arena-mib", str(arena_mib)]
    return cmd


def wait_healthy(proc, port, timeout):
    deadline = time.monotonic() + timeout
    url = f"http://127.0.0.1:{port}/health"
    while time.monotonic() < deadline:
        rc = proc.poll()
        if rc is not None:
            return False, f"server exited rc={rc} during startup"
        try:
            with urllib.request.urlopen(url, timeout=5) as resp:
                if resp.status == 200:
                    return True, "ready"
        except Exception:
            pass
        time.sleep(2.0)
    return False, f"not healthy within {timeout}s"


OOM_PAT = re.compile(
    r"out of memory|cudaMalloc failed|failed to allocate|CUDA error|ggml_backend_cuda_buffer",
    re.I,
)

# The fork prints one of these per adaptation. Capturing them per-arm is what
# lets us say whether streaming actually engaged and how hard the ring missed,
# instead of inferring it from throughput.
ADAPT_PAT = re.compile(r"kv_stream_adapt:.*")
MISS_PAT = re.compile(r"miss\s+([0-9.]+)%")
COPYBUSY_PAT = re.compile(r"copy busy\s+([0-9.]+)%")


def tail(path, n=40):
    try:
        lines = Path(path).read_text(errors="replace").splitlines()
    except OSError:
        return ""
    return "\n".join(lines[-n:])


def scan_adapt(path):
    """Extract streaming engagement evidence from a server log."""
    try:
        text = Path(path).read_text(errors="replace")
    except OSError:
        return {"adapt_lines": 0}
    lines = ADAPT_PAT.findall(text)
    info = {"adapt_lines": len(lines), "engaged": bool(lines)}
    if lines:
        info["adapt_last"] = lines[-1].strip()
        misses = [float(m) for m in MISS_PAT.findall(" ".join(lines))]
        busy = [float(m) for m in COPYBUSY_PAT.findall(" ".join(lines))]
        if misses:
            info["miss_pct_max"] = max(misses)
            info["miss_pct_last"] = misses[-1]
        if busy:
            info["copy_busy_pct_max"] = max(busy)
    return info


def degeneration_stats(tokens):
    """Cheap, objective shape metrics for a decoded token sequence.

    These do not decide anything on their own -- the token-id comparison does
    -- but they make "it degenerated" a number instead of an impression.
    """
    if not tokens:
        return {}
    n = len(tokens)
    distinct = len(set(tokens))
    longest = cur = 1
    for i in range(1, n):
        cur = cur + 1 if tokens[i] == tokens[i - 1] else 1
        longest = max(longest, cur)
    return {
        "n_tokens": n,
        "distinct_tokens": distinct,
        "distinct_ratio": round(distinct / n, 4),
        "longest_immediate_repeat": longest,
    }


def first_divergence(a_tokens, b_tokens):
    """Index of the first differing token, or None if one is a prefix of the other."""
    if not a_tokens or not b_tokens:
        return None
    for i, (x, y) in enumerate(zip(a_tokens, b_tokens)):
        if x != y:
            return i
    return None


def build_prompt(a, ctx, filler, suffix, prose_tokens):
    """Return (prompt_token_ids, description_dict)."""
    prompt_tokens = ctx - a.decode_tokens
    prefix_count = prompt_tokens - len(suffix)
    if prefix_count < 0:
        raise RuntimeError(f"context {ctx} too small for the prompt suffix")

    if filler == "token":
        fill_id = a.fill_token_id if a.fill_token_id is not None else suffix[0]
        prefix = [fill_id] * prefix_count
        desc = {"filler": "token", "fill_token_id": fill_id, "filler_tiled": False}
    elif filler == "prose":
        if not prose_tokens:
            raise RuntimeError(
                "filler=prose requested but no prose tokens are available; "
                "--filler-text-file must be supplied and non-empty"
            )
        tiled = len(prose_tokens) < prefix_count
        if tiled:
            reps = (prefix_count // len(prose_tokens)) + 1
            pool = (prose_tokens * reps)[:prefix_count]
        else:
            pool = prose_tokens[:prefix_count]
        prefix = pool
        desc = {
            "filler": "prose",
            "prose_token_pool": len(prose_tokens),
            "filler_tiled": tiled,
        }
    else:
        raise RuntimeError(f"unknown filler kind {filler!r}")

    return prefix + suffix, desc


def run_arm(a, ctx, arena_mib, filler, repeat, logs_dir, prose_cache):
    label = f"ctx{ctx}-arena{arena_mib}-{filler}-r{repeat}"
    log_path = logs_dir / f"{label}.log"
    row = {
        "type": "measurement", "context": ctx, "arena_mib": arena_mib,
        "streaming": arena_mib > 0, "filler": filler, "repeat": repeat,
        "label": label, "cell": f"ctx{ctx}-arena{arena_mib}-{filler}",
        "log": str(log_path), "status": "error",
    }
    cmd = server_command(a, ctx, arena_mib)
    row["command"] = " ".join(cmd)
    env = dict(os.environ)
    env.pop("LLAMA_ARG_KV_STREAM_ARENA_MIB", None)
    log_file = open(log_path, "wb")
    t_load0 = time.monotonic()
    proc = subprocess.Popen(cmd, stdout=log_file, stderr=subprocess.STDOUT,
                            env=env, cwd=str(a.server.parent))
    sampler = Sampler(a.nvidia_smi, a.gpu_index, proc.pid)
    sampler.start()
    try:
        ok, msg = wait_healthy(proc, a.port, a.startup_timeout)
        row["load_seconds"] = round(time.monotonic() - t_load0, 1)
        if not ok:
            logtail = tail(log_path)
            row["error"] = msg
            row["status"] = "oom" if OOM_PAT.search(logtail) else "startup_failed"
            row["log_tail"] = logtail
            return row

        # Tokenize the real suffix via the server's own tokenizer. An arbitrary
        # repeated token id is NOT a usable filler: build 992817 showed every
        # arm returning HTTP 500 with
        #   common_chat_peg_parse: unparsed Content-only output: ????
        # because the model, fed a wall of one meaningless id, emitted bytes
        # that are not valid UTF-8 and the chat parser rejected them.
        tok = http_json(f"http://127.0.0.1:{a.port}/tokenize",
                        {"content": a.prompt_suffix}, a.request_timeout)
        suffix = tok.get("tokens") or []
        if not suffix:
            raise RuntimeError(f"tokenizer returned no tokens for "
                               f"{a.prompt_suffix!r}")

        # Prose filler is tokenized once per process and cached: the text is
        # ~1 MiB and the tokenizer result does not depend on ctx or arena.
        if filler == "prose" and "tokens" not in prose_cache:
            text = Path(a.filler_text_file).read_text(errors="replace")
            text = text[: a.filler_text_chars]
            ptok = http_json(f"http://127.0.0.1:{a.port}/tokenize",
                             {"content": text}, a.request_timeout)
            prose_cache["tokens"] = ptok.get("tokens") or []
            print(f"### prose filler tokenized: {len(prose_cache['tokens'])} "
                  f"tokens from {len(text)} chars", flush=True)

        # warm-up: small request so allocation settles before we measure.
        # `reasoning_format: none` belongs on the REQUEST as well as the server
        # flag: Qwen3.8 is a reasoning model, and without it the server rejects
        # its own output with HTTP 500 "does not match the expected
        # Content-only format" (observed on build 989803, ctx32768-arena3072).
        warm_id = a.fill_token_id if a.fill_token_id is not None else suffix[0]
        http_json(f"http://127.0.0.1:{a.port}/completion",
                  {"prompt": [warm_id] * a.ubatch_size, "n_predict": 4,
                   "ignore_eos": True, "cache_prompt": False, "temperature": 0,
                   "reasoning_format": "none", "return_tokens": False},
                  a.request_timeout)

        prompt, pdesc = build_prompt(a, ctx, filler, suffix,
                                     prose_cache.get("tokens") or [])
        row.update(pdesc)
        t0 = time.monotonic()
        resp = http_json(
            f"http://127.0.0.1:{a.port}/completion",
            # return_tokens is the point of this run: the decoded token ids at
            # temperature 0 are the exactness test. Text is kept too, but only
            # as a human-readable sidecar.
            {"prompt": prompt, "n_predict": a.decode_tokens, "ignore_eos": True,
             "cache_prompt": False, "temperature": 0,
             "reasoning_format": "none", "return_tokens": True},
            a.request_timeout,
        )
        row["wall_seconds"] = round(time.monotonic() - t0, 1)
        timings = resp.get("timings", {})
        row["timings"] = timings
        row["prompt_tokens"] = timings.get("prompt_n")
        row["pp_tokens_per_second"] = timings.get("prompt_per_second")
        row["tg_tokens_per_second"] = timings.get("predicted_per_second")
        row["predicted_n"] = timings.get("predicted_n")
        out_tokens = resp.get("tokens") or []
        row["output_tokens"] = out_tokens
        row.update(degeneration_stats(out_tokens))
        row["sample_text"] = (resp.get("content") or "")[:400]
        row["full_text"] = resp.get("content") or ""
        row["status"] = "ok"
        return row
    except urllib.error.URLError as exc:
        logtail = tail(log_path)
        row["error"] = f"request failed: {exc}"
        row["status"] = "oom" if OOM_PAT.search(logtail) else "request_failed"
        row["log_tail"] = logtail
        return row
    except Exception as exc:  # noqa: BLE001 - recorded, not swallowed
        logtail = tail(log_path)
        row["error"] = f"{type(exc).__name__}: {exc}"
        row["status"] = "oom" if OOM_PAT.search(logtail) else "failed"
        row["log_tail"] = logtail
        return row
    finally:
        sampler.stop()
        row["peak_vram_mib"] = sampler.peak_vram_mib
        row["peak_rss_mib"] = round(sampler.peak_rss_kib / 1024)
        if proc.poll() is None:
            proc.send_signal(signal.SIGINT)
            try:
                proc.wait(timeout=60)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait(timeout=30)
        row["server_exit"] = proc.returncode
        log_file.close()
        row.update(scan_adapt(log_path))
        # VRAM release is asynchronous: the process can be reaped while the
        # driver still holds its allocation. Starting the next arm early makes
        # it OOM on memory that is about to be freed, which reads as a false
        # capacity result. Build 989803 measured only 18748 MiB free at the
        # first arm for exactly this reason. Wait for the GPU to return to
        # within `settle_slack_mib` of the pre-run idle baseline.
        deadline = time.monotonic() + a.settle_timeout
        target = a.idle_vram_mib + a.settle_slack_mib
        while time.monotonic() < deadline:
            try:
                cur = gpu_used_mib(a.nvidia_smi, a.gpu_index)
            except Exception:
                break
            if cur <= target:
                break
            time.sleep(2)
        row["vram_after_release_mib"] = gpu_used_mib(a.nvidia_smi, a.gpu_index)
        time.sleep(a.release_pause)


def parse_arms(spec):
    """`ctx:arena:repeats:filler,...` -> list of (ctx, arena, filler, repeat)."""
    arms = []
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        parts = chunk.split(":")
        if len(parts) != 4:
            raise ValueError(
                f"bad arm spec {chunk!r}; expected ctx:arena:repeats:filler"
            )
        ctx, arena, reps, filler = parts
        filler = filler.strip()
        if filler not in ("token", "prose"):
            raise ValueError(f"bad filler {filler!r} in {chunk!r}")
        for r in range(1, int(reps) + 1):
            arms.append((int(ctx), int(arena), filler, r))
    if not arms:
        raise ValueError("no arms parsed")
    return arms


def analyze(rows):
    """Correctness verdicts derived from the recorded token ids.

    Two independent checks, both only meaningful because every arm runs at
    temperature 0 with cache_prompt off:

      exactness  -- a streaming-on arm compared against the streaming-off arm
                    (arena 0) at the same context and filler. The fork claims
                    exact attention; any divergence contradicts it.
      determinism -- repeats of the same cell compared against each other.
                    A correct implementation cannot disagree with itself.
    """
    ok = [r for r in rows if r["status"] == "ok" and r.get("output_tokens")]
    findings = []

    # determinism within a cell
    cells = {}
    for r in ok:
        cells.setdefault(r["cell"], []).append(r)
    for cell, group in sorted(cells.items()):
        group.sort(key=lambda r: r["repeat"])
        base = group[0]
        for other in group[1:]:
            idx = first_divergence(base["output_tokens"], other["output_tokens"])
            same_len = len(base["output_tokens"]) == len(other["output_tokens"])
            findings.append({
                "check": "determinism", "cell": cell,
                "a": base["label"], "b": other["label"],
                "first_divergence": idx,
                "identical": idx is None and same_len,
            })

    # exactness vs the streaming-off control at the same (ctx, filler)
    controls = {}
    for r in ok:
        if r["arena_mib"] == 0 and r["repeat"] == 1:
            controls[(r["context"], r["filler"])] = r
    for r in ok:
        if r["arena_mib"] == 0:
            continue
        ctrl = controls.get((r["context"], r["filler"]))
        if not ctrl:
            continue
        idx = first_divergence(ctrl["output_tokens"], r["output_tokens"])
        same_len = len(ctrl["output_tokens"]) == len(r["output_tokens"])
        findings.append({
            "check": "exactness", "cell": r["cell"],
            "a": ctrl["label"], "b": r["label"],
            "first_divergence": idx,
            "identical": idx is None and same_len,
        })
    return findings


def render_table(rows):
    hdr = (f"{'ctx':>8} {'arena':>7} {'filler':>7} {'r':>2} {'stream':>7} "
           f"{'PP_tok/s':>10} {'TG_tok/s':>9} {'peakVRAM':>9} {'distinct':>9} "
           f"{'maxrepeat':>10} {'miss%':>7} {'status':>14}")
    lines = [hdr, "-" * len(hdr)]
    for r in rows:
        lines.append(
            f"{r['context']:>8} {r['arena_mib']:>7} {r.get('filler', '?'):>7} "
            f"{r.get('repeat', 0):>2} "
            f"{('on' if r['streaming'] else 'OFF'):>7} "
            f"{(round(r.get('pp_tokens_per_second') or 0, 1)):>10} "
            f"{(round(r.get('tg_tokens_per_second') or 0, 2)):>9} "
            f"{r.get('peak_vram_mib', 0):>9} "
            f"{r.get('distinct_tokens', 0):>9} "
            f"{r.get('longest_immediate_repeat', 0):>10} "
            f"{(r.get('miss_pct_last') if r.get('miss_pct_last') is not None else '-'):>7} "
            f"{r['status']:>14}"
        )
    return "\n".join(lines)


def render_findings(findings):
    if not findings:
        return "(no comparable arm pairs)"
    hdr = f"{'check':>12}  {'verdict':>9}  {'firstdiff':>9}  A vs B"
    lines = [hdr, "-" * (len(hdr) + 40)]
    for f in findings:
        verdict = "IDENTICAL" if f["identical"] else "DIVERGED"
        idx = "-" if f["first_divergence"] is None else f["first_divergence"]
        lines.append(f"{f['check']:>12}  {verdict:>9}  {idx:>9}  "
                     f"{f['a']}  vs  {f['b']}")
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument("--model", type=Path, required=True)
    p.add_argument("--server", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--arms", required=True,
                   help="comma list of ctx:arena:repeats:filler, e.g. "
                        "262144:0:3:token,262144:3072:3:token")
    p.add_argument("--decode-tokens", type=int, default=256)
    p.add_argument("--batch-size", type=int, default=256)
    p.add_argument("--ubatch-size", type=int, default=256)
    p.add_argument("--cache-type-k", default="q8_0")
    p.add_argument("--cache-type-v", default="q4_0")
    p.add_argument("--fill-token-id", type=int, default=None,
                   help="filler token id for filler=token; default is the "
                        "first token of --prompt-suffix")
    p.add_argument("--prompt-suffix", default="The capital of France is",
                   help="real text placed at the end of the filler prompt so "
                        "the model has something coherent to continue")
    p.add_argument("--filler-text-file", type=Path, default=None,
                   help="real prose used as the prefix for filler=prose arms")
    p.add_argument("--filler-text-chars", type=int, default=1600000,
                   help="how much of the prose file to tokenize; 262144 "
                        "tokens is roughly 1.1 MiB of English")
    p.add_argument("--gpu-index", type=int, default=0)
    p.add_argument("--nvidia-smi", default="nvidia-smi")
    p.add_argument("--port", type=int, default=12355)
    p.add_argument("--startup-timeout", type=int, default=900)
    p.add_argument("--request-timeout", type=int, default=3600)
    p.add_argument("--release-pause", type=float, default=10.0)
    p.add_argument("--settle-timeout", type=float, default=180.0)
    p.add_argument("--settle-slack-mib", type=int, default=512)
    a = p.parse_args(argv)

    arms = parse_arms(a.arms)
    if any(f == "prose" for _, _, f, _ in arms):
        if not a.filler_text_file or not a.filler_text_file.is_file():
            print("FATAL: prose arms requested but --filler-text-file is "
                  "missing or not a file. Refusing to silently fall back to "
                  "the repetitive filler, which is the variable under test.",
                  file=sys.stderr)
            return 2

    a.output_dir.mkdir(parents=True, exist_ok=True)
    logs_dir = a.output_dir / "logs"
    logs_dir.mkdir(exist_ok=True)
    jsonl = a.output_dir / "results.jsonl"

    meta = {
        "type": "metadata",
        "model": str(a.model),
        "model_bytes": a.model.stat().st_size,
        "server": str(a.server),
        "arms": [{"context": c, "arena_mib": ar, "filler": f, "repeat": r}
                 for c, ar, f, r in arms],
        "decode_tokens": a.decode_tokens,
        "batch_size": a.batch_size, "ubatch_size": a.ubatch_size,
        "cache_type_k": a.cache_type_k, "cache_type_v": a.cache_type_v,
        "prompt_suffix": a.prompt_suffix,
        "filler_text_file": str(a.filler_text_file) if a.filler_text_file else None,
        "started_at": time.time(),
    }
    if a.filler_text_file and a.filler_text_file.is_file():
        meta["filler_text_bytes"] = a.filler_text_file.stat().st_size
    try:
        meta["gpu"] = subprocess.run(
            [a.nvidia_smi, "--query-gpu=name,memory.total,driver_version",
             "--format=csv,noheader"],
            stdout=subprocess.PIPE, text=True, check=True).stdout.strip()
        meta["idle_vram_mib"] = gpu_used_mib(a.nvidia_smi, a.gpu_index)
        a.idle_vram_mib = meta["idle_vram_mib"]
    except Exception as exc:  # noqa: BLE001
        meta["gpu_error"] = str(exc)
        a.idle_vram_mib = 0
    with jsonl.open("a") as fh:
        fh.write(json.dumps(meta, sort_keys=True) + "\n")
    print(json.dumps(meta, sort_keys=True), flush=True)

    rows = []
    prose_cache = {}
    for i, (ctx, arena, filler, repeat) in enumerate(arms, 1):
        print(f"### RUN {i}/{len(arms)} ctx={ctx} arena={arena} "
              f"filler={filler} repeat={repeat}", flush=True)
        row = run_arm(a, ctx, arena, filler, repeat, logs_dir, prose_cache)
        rows.append(row)
        with jsonl.open("a") as fh:
            fh.write(json.dumps(row, sort_keys=True) + "\n")
        # output_tokens is up to 256 ids and full_text can be long; keep the
        # build log readable without hiding the numbers that matter.
        printable = {k: v for k, v in row.items()
                     if k not in ("log_tail", "output_tokens", "full_text")}
        print(json.dumps(printable, sort_keys=True), flush=True)
        if row["status"] != "ok":
            print(f"### ARM FAILED ({row['status']}): {row.get('error')}",
                  flush=True)
            print(row.get("log_tail", ""), flush=True)

    table = render_table(rows)
    findings = analyze(rows)
    findings_txt = render_findings(findings)

    with jsonl.open("a") as fh:
        for f in findings:
            fh.write(json.dumps({"type": "finding", **f}, sort_keys=True) + "\n")

    report = (
        table
        + "\n\nTOKEN-IDENTITY CHECKS (temperature 0, cache_prompt off)\n"
        + "  exactness   = streaming arm vs its arena=0 control, same ctx+filler\n"
        + "  determinism = repeats of the same cell against each other\n\n"
        + findings_txt + "\n"
    )
    (a.output_dir / "results.txt").write_text(report)
    print("\n" + report, flush=True)

    # Sample text per arm, for the human reading the artifact.
    samples = []
    for r in rows:
        samples.append(f"=== {r['label']} ({r['status']}) ===\n"
                       + (r.get("full_text") or r.get("error") or "") + "\n")
    (a.output_dir / "samples.txt").write_text("\n".join(samples))

    ok_count = sum(1 for r in rows if r["status"] == "ok")
    print(f"\nOK_ARMS={ok_count}/{len(rows)}", flush=True)
    return 0 if ok_count > 0 else 1


if __name__ == "__main__":
    sys.exit(main())
